<div>
		<footer>
			<p>Folha de Ponto Jovem Aprendiz Senac Jataí | Desenvolvedor Xenofriends Techonology Solution</p>
		</footer>
	</div>
		
</body>
</html>