<?php 
	$HOST = "localhost";
	$USER = "root";
	$PASS = "";
	$DB = "jovemaprendiz";

	$connect = mysqli_connect($HOST, $USER, $PASS, $DB);
	
?>