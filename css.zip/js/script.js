$(document).ready(function(){

	$('#select_all').change(function() {
	  var checkboxes = $(this).closest('form').find(':checkbox');
	  checkboxes.prop('checked', $(this).is(':checked'));
	});
	
	$("#entrada").click(function(){
		var vals=valores();
		console.log(vals);
		var vazio=estaVazioEntrada();
		if(!vazio){
			alert("Existem valores vazios verifique-os e tente novamente");
			return;
		}

		for (var i = 0; i <= vals.length-1; i++) {
			var id="."+vals[i]+"";
			var data = $("#data_ponto").val();
			var entrada = $("#entrada_hora").val();
			var id_ponto = ""+data+id;
			query= "INSERT INTO ponto (id_ponto, data, entrada, id_aluno) VALUES ('"+id_ponto+"', '"+data+"', '"+entrada+"', '"+vals[i]+"') ON DUPLICATE KEY UPDATE entrada = '"+entrada+"'";
				alert(query);
				$.ajax({
	                url: 'bibliotecas/alunodb.php',
	                type: 'post',
	                async: false,
	                data: {
	                	sql: query
	                },
	                success:function(data){
	                	if(data=="1"){
	                		$(id).addClass("bg-success");
	                	}else{
	                		alert(data+" informe o administrador do site");
	                	}
	                }
	            });
		}
	});


	$("#saida").click(function(){
		var vals=valores();
		console.log(vals);
		var vazio=estaVazioSaida();
		if(!vazio){
			alert("Existem valores vazios verifique-os e tente novamente");
			return;
		}

		for (var i = 0; i <= vals.length-1; i++) {
			var id="."+vals[i]+"";
			var data = $("#data_ponto").val();
			var saida = $("#saida_hora").val();
			var id_ponto = ""+data+id;
			query= "INSERT INTO ponto (id_ponto, data, saida, id_aluno) VALUES ('"+id_ponto+"', '"+data+"', '"+saida+"', '"+vals[i]+"') ON DUPLICATE KEY UPDATE saida = '"+saida+"'";
				alert(query);
				$.ajax({
	                url: 'bibliotecas/alunodb.php',
	                type: 'post',
	                async: false,
	                data: {
	                	sql: query
	                },
	                success:function(data){
	                	if(data=="1"){
	                		$(id).addClass("bg-warning");
	                	}else{
	                		alert(data+" informe o administrador do site");
	                	}
	                }
	            });
		}
	});

$("#falta").click(function(){
		var vals=valores();
		console.log(vals);
		var vazio=estaVazioData();
		if(!vazio){
			alert("Existem valores vazios verifique-os e tente novamente");
			return;
		}

		for (var i = 0; i <= vals.length-1; i++) {
			var id="."+vals[i]+"";
			var data = $("#data_ponto").val();
			var id_ponto = ""+data+id;
			query= "REPLACE INTO ponto (id_ponto, data, entrada, saida, id_aluno) VALUES ('"+id_ponto+"', '"+data+"', 'Falta', 'Falta', '"+vals[i]+"')";
				alert(query);
				$.ajax({
	                url: 'bibliotecas/alunodb.php',
	                type: 'post',
	                async: false,
	                data: {
	                	sql: query
	                },
	                success:function(data){
	                	if(data=="1"){
	                		$(id).addClass("bg-danger");
	                	}else{
	                		alert(data+" informe o administrador do site");
	                	}
	                }
	            });
		}
	});

$("#empresa").click(function(){
		var vals=valores();
		console.log(vals);
		var vazio=estaVazioData();
		if(!vazio){
			alert("Existem valores vazios verifique-os e tente novamente");
			return;
		}

		for (var i = 0; i <= vals.length-1; i++) {
			var id="."+vals[i]+"";
			var data = $("#data_ponto").val();
			var id_ponto = ""+data+id;
			query= "REPLACE INTO ponto (id_ponto, data, entrada, saida, id_aluno) VALUES ('"+id_ponto+"', '"+data+"', 'Na Empresa', 'Na Empresa', '"+vals[i]+"')";
				alert(query);
				$.ajax({
	                url: 'bibliotecas/alunodb.php',
	                type: 'post',
	                async: false,
	                data: {
	                	sql: query
	                },
	                success:function(data){
	                	if(data=="1"){
	                		$(id).addClass("bg-primary");
	                	}else{
	                		alert(data+" informe o administrador do site");
	                	}
	                }
	            });
		}
	});

$("#Recesso").click(function(){
		var vals=valores();
		console.log(vals);
		var vazio=estaVazioData();
		if(!vazio){
			alert("Existem valores vazios verifique-os e tente novamente");
			return;
		}

		for (var i = 0; i <= vals.length-1; i++) {
			var id="."+vals[i]+"";
			var data = $("#data_ponto").val();
			var id_ponto = ""+data+id;
			query= "REPLACE INTO ponto (id_ponto, data, entrada, saida, id_aluno) VALUES ('"+id_ponto+"', '"+data+"', 'Feriado/Recesso', 'Feriado/Recesso', '"+vals[i]+"')";
				alert(query);
				$.ajax({
	                url: 'bibliotecas/alunodb.php',
	                type: 'post',
	                async: false,
	                data: {
	                	sql: query
	                },
	                success:function(data){
	                	if(data=="1"){
	                		$(id).addClass("bg-primary");
	                	}else{
	                		alert(data+" informe o administrador do site");
	                	}
	                }
	            });
		}
	});

	$("#desligado").click(function(){
		var vals=valores();
		console.log(vals);
		var query="";
		if (confirm("Tem certeza que deseja desligar este jovem?")) {
			for (var i = 0; i <= vals.length-1; i++) {
				var id="."+vals[i]+"";
				query= "UPDATE aluno SET matriculado = 'Não' WHERE codigo = "+vals[i];
				$.ajax({
	                url: 'bibliotecas/alunodb.php',
	                type: 'post',
	                async: false,
	                data: {
	                	sql: query
	                },
	                success:function(data){
	                	if(data=="1"){
	                		alert("Aluno desligado com sucesso");
	                		$(id).hide();
	                	}else{
	                		alert(data+" informe o administrador do site");
	                	}
	                }
	            });
			}
			console.log(query);
		}
		
	});
	function valores(){
		var checkValues = $('input[name=codigo_aluno]:checked').map(function()
            {
                return $(this).val();
            }).get();
		return checkValues;
	}
	function estaVazioEntrada(){
		var vals = valores;
		var data= $("#data_ponto").val();
		var entrada = $("#entrada_hora").val();
		//var saida = $("#saida_hora").val();

		if (!vals || !data || !entrada ) {
			return false;
		}
		return true;
	}

	function estaVazioSaida(){
		var vals = valores;
		var data= $("#data_ponto").val();
		//var entrada = $("#entrada_hora").val();
		var saida = $("#saida_hora").val();

		if (!vals || !data || !saida ) {
			return false;
		}
		return true;
	}
	function estaVazioData(){
		var vals = valores;
		var data= $("#data_ponto").val();
		//var entrada = $("#entrada_hora").val();
		//var saida = $("#saida_hora").val();

		if (!vals || !data ) {
			return false;
		}
		return true;
	}
});